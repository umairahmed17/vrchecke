<?php
/**
 * Template part for displaying a post's summary
 *
 * @package vrchecke
 */

namespace VRCHECKE\VRCHECKE;

?>

<div class="entry-summary">
	<?php the_excerpt(); ?>
</div><!-- .entry-summary -->
