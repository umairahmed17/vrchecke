<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package vrchecke
 */

namespace VRCHECKE\VRCHECKE;

?>
<!doctype html>
<html <?php language_attributes(); ?> class="no-js">

<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">

	<?php
	if ( ! vrchecke()->is_amp() ) {
		?>
	<script>
	document.documentElement.classList.remove('no-js');
	</script>
		<?php
	}
	?>

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<?php wp_body_open(); ?>
	<div id="page" class="site">
		<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'vrchecke' ); ?></a>

		<header id="masthead" class="site-header">
			<div class="custom-shape-divider-bottom-1639733818">
				<svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1undefined20"
					preserveAspectRatio="none">
					<path
						d="M985.66,92.83C906.67,72,823.78,31,743.84,14.19c-82.26-17.34-168.06-16.33-250.45.39-57.84,11.73-114,31.07-172,41.86A600.21,600.21,0,0,1,0,27.35V120H1200V95.8C1132.19,118.92,1055.71,111.31,985.66,92.83Z"
						class="shape-fill"></path>
				</svg>
			</div>
			<?php get_template_part( 'template-parts/header/custom_header' ); ?>

			<?php get_template_part( 'template-parts/header/branding' ); ?>

			<?php get_template_part( 'template-parts/header/navigation' ); ?>
		</header><!-- #masthead -->
